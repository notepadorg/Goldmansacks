from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from database import execute_procedure


def load_parameter_config(path: Path) -> dict[str, list[Any]]:
    if not path.exists():
        return {}

    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def run_all(
    connection,
    settings,
    parameter_config: dict[str, list[Any]],
):
    procedures = [
        settings.sp_manual_update,
        settings.sp_load_related_claims,
        settings.sp_update_count,
        settings.sp_null_zip_count,
    ]

    results = {}

    for procedure in procedures:
        short_name = procedure.split(".")[-1]
        params = parameter_config.get(short_name, [])

        if not settings.procedures_have_parameters:
            params = []

        results[short_name] = execute_procedure(
            connection,
            procedure,
            params,
        )

    return results
