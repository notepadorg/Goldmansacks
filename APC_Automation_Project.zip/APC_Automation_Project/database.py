from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable, Sequence

import pyodbc

from config import Settings


IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$")


def validate_identifier(value: str) -> str:
    """Allow only simple SQL identifiers such as dbo.Table or procName."""
    if not IDENTIFIER_RE.fullmatch(value):
        raise ValueError(f"Unsafe SQL identifier: {value!r}")
    return value


def get_connection(settings: Settings) -> pyodbc.Connection:
    parts = [
        f"DRIVER={{{settings.db_driver}}}",
        f"SERVER={settings.db_server}",
        f"DATABASE={settings.db_name}",
    ]

    if settings.db_trusted_connection:
        parts.append("Trusted_Connection=yes")
    else:
        parts.extend(
            [
                f"UID={settings.db_user}",
                f"PWD={settings.db_password}",
            ]
        )

    connection_string = ";".join(parts) + ";"
    return pyodbc.connect(connection_string, timeout=30)


def execute_sql(
    connection: pyodbc.Connection,
    sql: str,
    params: Sequence | None = None,
) -> None:
    cursor = connection.cursor()
    try:
        cursor.execute(sql, params or [])
        connection.commit()
    finally:
        cursor.close()


def execute_procedure(
    connection: pyodbc.Connection,
    procedure_name: str,
    params: Sequence | None = None,
) -> list[tuple]:
    procedure_name = validate_identifier(procedure_name)
    placeholders = ", ".join("?" for _ in (params or []))
    sql = f"EXEC {procedure_name}"
    if placeholders:
        sql += f" {placeholders}"

    cursor = connection.cursor()
    try:
        cursor.execute(sql, params or [])
        rows = cursor.fetchall() if cursor.description else []
        connection.commit()
        return rows
    finally:
        cursor.close()


def table_exists(connection: pyodbc.Connection, table_name: str) -> bool:
    table_name = validate_identifier(table_name)
    if "." in table_name:
        schema, table = table_name.split(".", 1)
    else:
        schema, table = "dbo", table_name

    cursor = connection.cursor()
    try:
        cursor.execute(
            """
            SELECT 1
            FROM sys.tables t
            INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
            WHERE s.name = ? AND t.name = ?
            """,
            schema,
            table,
        )
        return cursor.fetchone() is not None
    finally:
        cursor.close()


def create_temp_table(connection: pyodbc.Connection, table_name: str) -> None:
    table_name = validate_identifier(table_name)
    if "." in table_name:
        schema, table = table_name.split(".", 1)
        qualified = f"[{schema}].[{table}]"
    else:
        qualified = f"[dbo].[{table_name}]"

    sql = f"""
    IF OBJECT_ID(N'{schema if "." in table_name else "dbo"}.{table}', N'U') IS NOT NULL
        DROP TABLE {qualified};

    CREATE TABLE {qualified} (
        [Claimnumber]   varchar(255),
        [TaxId]         varchar(255),
        [Campus_unit]   varchar(255),
        [NPIID]         varchar(255),
        [ProviderName]  varchar(255),
        [Address_line1] varchar(255),
        [Address_line2] varchar(255),
        [City]          varchar(255),
        [State]         varchar(255),
        [Zip_code]      varchar(255),
        [UpdatedBY]     varchar(255),
        [AuditProgram]  varchar(255)
    );
    """
    execute_sql(connection, sql)


def truncate_temp_table(connection: pyodbc.Connection, table_name: str) -> None:
    table_name = validate_identifier(table_name)
    execute_sql(connection, f"TRUNCATE TABLE {table_name}")


def drop_temp_table(connection: pyodbc.Connection, table_name: str) -> None:
    table_name = validate_identifier(table_name)
    execute_sql(
        connection,
        f"""
        IF OBJECT_ID(N'{table_name}', N'U') IS NOT NULL
            DROP TABLE {table_name};
        """,
    )


def bulk_insert(
    connection: pyodbc.Connection,
    table_name: str,
    rows: Iterable[Sequence],
) -> int:
    table_name = validate_identifier(table_name)

    insert_sql = f"""
        INSERT INTO {table_name}
        (
            Claimnumber, TaxId, Campus_unit, NPIID,
            ProviderName, Address_line1, Address_line2,
            City, State, Zip_code, UpdatedBY, AuditProgram
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    cursor = connection.cursor()
    try:
        cursor.fast_executemany = True
        count = 0
        batch = []

        for row in rows:
            batch.append(tuple(row))
            if len(batch) >= 1000:
                cursor.executemany(insert_sql, batch)
                count += len(batch)
                batch.clear()

        if batch:
            cursor.executemany(insert_sql, batch)
            count += len(batch)

        connection.commit()
        return count
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
