IF OBJECT_ID(N'dbo.tmpAPCManualupdate', N'U') IS NOT NULL
    DROP TABLE dbo.tmpAPCManualupdate;
GO

CREATE TABLE dbo.tmpAPCManualupdate
(
    [Claimnumber]   varchar(255),
    [TaxId]         varchar(255),
    [Campus_unit]   varchar(255),
    [NPIID]         varchar(255),
    [ProviderName]  varchar(255),
    [Address_line1] varchar(255),
    [Address_line2] varchar(255),
    [City]          varchar(255),
    [State]         varchar(255),
    [Zip_code]      varchar(255),
    [UpdatedBY]     varchar(255),
    [AuditProgram]  varchar(255)
);
GO
