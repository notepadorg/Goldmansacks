from __future__ import annotations

from pathlib import Path


class RunLock:
    """Simple Windows-friendly single-instance lock using an atomic directory create."""

    def __init__(self, lock_path: Path):
        self.lock_path = lock_path

    def acquire(self):
        try:
            self.lock_path.mkdir()
        except FileExistsError:
            raise RuntimeError(
                f"Another APC automation instance appears to be running: {self.lock_path}"
            )

    def release(self):
        try:
            self.lock_path.rmdir()
        except FileNotFoundError:
            pass

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release()
