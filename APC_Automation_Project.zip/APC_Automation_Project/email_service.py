from __future__ import annotations

import smtplib
from email.message import EmailMessage

from config import Settings


def _split_recipients(value: str) -> list[str]:
    return [
        x.strip()
        for x in value.replace(";", ",").split(",")
        if x.strip()
    ]


def send_email(
    settings: Settings,
    subject: str,
    body: str,
    recipients: str,
    cc: str = "",
) -> None:
    if not settings.email_enabled:
        return

    to_list = _split_recipients(recipients)
    cc_list = _split_recipients(cc)

    if not to_list:
        raise ValueError("Email is enabled but no recipient is configured.")

    message = EmailMessage()
    message["From"] = settings.mail_from
    message["To"] = ", ".join(to_list)
    if cc_list:
        message["Cc"] = ", ".join(cc_list)
    message["Subject"] = subject
    message.set_content(body)

    with smtplib.SMTP(
        settings.smtp_server,
        settings.smtp_port,
        timeout=30,
    ) as smtp:
        if settings.smtp_use_tls:
            smtp.starttls()

        smtp.send_message(message)


def send_success_mail(settings: Settings, file_name: str, details: str) -> None:
    send_email(
        settings=settings,
        subject=settings.success_subject,
        body=(
            "APC Manual Process completed successfully.\n\n"
            f"File: {file_name}\n"
            f"{details}"
        ),
        recipients=settings.mail_to,
        cc=settings.mail_cc,
    )


def send_failure_mail(
    settings: Settings,
    file_name: str,
    error: str,
) -> None:
    send_email(
        settings=settings,
        subject=settings.failure_subject,
        body=(
            "APC Manual Process failed for a file.\n\n"
            f"File: {file_name}\n"
            f"Error: {error}\n"
        ),
        recipients=settings.mail_failure_to,
    )
