from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parent
load_dotenv(PROJECT_ROOT / ".env")


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    return int(value)


@dataclass(frozen=True)
class Settings:
    db_server: str
    db_name: str
    db_driver: str
    db_trusted_connection: bool
    db_user: str
    db_password: str

    process_root: Path
    done_root: Path
    error_root: Path

    allowed_extensions: tuple[str, ...]
    filename_pattern: str
    recursive_subfolders: bool

    temp_table: str
    sp_manual_update: str
    sp_load_related_claims: str
    sp_update_count: str
    sp_null_zip_count: str
    procedures_have_parameters: bool

    email_enabled: bool
    smtp_server: str
    smtp_port: int
    smtp_use_tls: bool
    mail_from: str
    mail_to: str
    mail_cc: str
    mail_failure_to: str
    success_subject: str
    failure_subject: str

    max_files_per_run: int
    move_duplicate_to_error: bool
    delete_temp_table_on_exit: bool


def load_settings() -> Settings:
    process_root = Path(os.environ["APC_PROCESS_ROOT"])
    done_root = Path(os.getenv("APC_DONE_ROOT", "") or process_root.parent / "APCDone")
    error_root = Path(os.getenv("APC_ERROR_ROOT", "") or process_root.parent / "APCError")

    extensions = tuple(
        x.strip().lower()
        for x in os.getenv("ALLOWED_EXTENSIONS", ".xlsx,.xlsm").split(",")
        if x.strip()
    )

    return Settings(
        db_server=os.environ["DB_SERVER"],
        db_name=os.environ["DB_NAME"],
        db_driver=os.getenv("DB_DRIVER", "ODBC Driver 17 for SQL Server"),
        db_trusted_connection=env_bool("DB_TRUSTED_CONNECTION", True),
        db_user=os.getenv("DB_USER", ""),
        db_password=os.getenv("DB_PASSWORD", ""),

        process_root=process_root,
        done_root=done_root,
        error_root=error_root,

        allowed_extensions=extensions,
        filename_pattern=os.getenv("FILENAME_PATTERN", "").strip(),
        recursive_subfolders=env_bool("RECURSIVE_SUBFOLDERS", False),

        temp_table=os.getenv("TEMP_TABLE", "dbo.tmpAPCManualupdate"),
        sp_manual_update=os.getenv("SP_MANUAL_UPDATE", "dbo.papcManualUpdate"),
        sp_load_related_claims=os.getenv(
            "SP_LOAD_RELATED_CLAIMS", "dbo.papcLoadRelatedClaims"
        ),
        sp_update_count=os.getenv("SP_UPDATE_COUNT", "dbo.papcUpdateCount"),
        sp_null_zip_count=os.getenv("SP_NULL_ZIP_COUNT", "dbo.papcNullZipCount"),
        procedures_have_parameters=env_bool("PROCEDURES_HAVE_PARAMETERS", False),

        email_enabled=env_bool("EMAIL_ENABLED", False),
        smtp_server=os.getenv("SMTP_SERVER", ""),
        smtp_port=env_int("SMTP_PORT", 25),
        smtp_use_tls=env_bool("SMTP_USE_TLS", False),
        mail_from=os.getenv("MAIL_FROM", ""),
        mail_to=os.getenv("MAIL_TO", ""),
        mail_cc=os.getenv("MAIL_CC", ""),
        mail_failure_to=os.getenv("MAIL_FAILURE_TO", ""),
        success_subject=os.getenv(
            "SUCCESS_SUBJECT", "APC Manual Process - Success"
        ),
        failure_subject=os.getenv(
            "FAILURE_SUBJECT", "APC Manual Process - Failure"
        ),

        max_files_per_run=env_int("MAX_FILES_PER_RUN", 0),
        move_duplicate_to_error=env_bool("MOVE_DUPLICATE_TO_ERROR", False),
        delete_temp_table_on_exit=env_bool("DELETE_TEMP_TABLE_ON_EXIT", True),
    )


SETTINGS = load_settings()
