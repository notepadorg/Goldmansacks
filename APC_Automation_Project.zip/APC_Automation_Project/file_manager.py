from __future__ import annotations

import re
import shutil
from pathlib import Path


def get_subfolders(root: Path, recursive: bool = False) -> list[Path]:
    if not root.exists():
        raise FileNotFoundError(f"Process root does not exist: {root}")

    if recursive:
        return sorted(p for p in root.rglob("*") if p.is_dir())

    return sorted(p for p in root.iterdir() if p.is_dir())


def get_excel_files(
    folder: Path,
    allowed_extensions: tuple[str, ...],
) -> list[Path]:
    extensions = {e.lower() for e in allowed_extensions}
    return sorted(
        p
        for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() in extensions
    )


def validate_filename(
    file_path: Path,
    filename_pattern: str = "",
) -> bool:
    if not filename_pattern:
        return True

    return re.fullmatch(filename_pattern, file_path.name) is not None


def unique_destination(destination: Path) -> Path:
    """Avoid overwriting an existing file unless the caller explicitly chooses otherwise."""
    if not destination.exists():
        return destination

    stem = destination.stem
    suffix = destination.suffix

    counter = 1
    while True:
        candidate = destination.with_name(
            f"{stem}_{counter}{suffix}"
        )
        if not candidate.exists():
            return candidate
        counter += 1


def move_file(
    source: Path,
    destination_folder: Path,
    preserve_relative_name: bool = True,
) -> Path:
    destination_folder.mkdir(parents=True, exist_ok=True)

    destination = destination_folder / source.name
    destination = unique_destination(destination)

    shutil.move(str(source), str(destination))
    return destination
