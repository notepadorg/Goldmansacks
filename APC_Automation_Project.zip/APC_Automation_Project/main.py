from __future__ import annotations

import sys
import traceback
from pathlib import Path

from config import PROJECT_ROOT, SETTINGS, load_settings
from database import (
    bulk_insert,
    create_temp_table,
    drop_temp_table,
    get_connection,
    truncate_temp_table,
)
from email_service import send_failure_mail, send_success_mail
from excel_processor import dataframe_rows, read_excel
from file_manager import (
    get_excel_files,
    get_subfolders,
    move_file,
    validate_filename,
)
from lock import RunLock
from logging_setup import setup_logging
from procedure_runner import load_parameter_config, run_all


LOGGER = setup_logging(PROJECT_ROOT / "logs")
LOCK_PATH = PROJECT_ROOT / "run.lock"


def get_done_folder(settings, subfolder: Path) -> Path:
    # This mirrors the SSIS concept of "Get The done Folder".
    # Adjust this function only if your SSIS builds a different per-subfolder path.
    return settings.done_root / subfolder.name


def get_error_folder(settings, subfolder: Path) -> Path:
    # This mirrors the SSIS concept of "Get The Error Folder".
    return settings.error_root / subfolder.name


def process_file(
    connection,
    settings,
    file_path: Path,
    subfolder: Path,
    procedure_params,
):
    LOGGER.info("Starting file: %s", file_path)

    if not validate_filename(file_path, settings.filename_pattern):
        raise ValueError(
            f"Filename does not match configured convention: {file_path.name}"
        )

    # SSIS: Excel Source -> Data Conversion
    df = read_excel(file_path)
    LOGGER.info("Read %d Excel rows from %s", len(df), file_path.name)

    # Keep the same permanent temp-table design used by the SSIS package.
    # Truncate before each file so data from the previous file cannot leak into this file.
    truncate_temp_table(connection, settings.temp_table)

    inserted = bulk_insert(
        connection,
        settings.temp_table,
        dataframe_rows(df),
    )
    LOGGER.info("Loaded %d rows into %s", inserted, settings.temp_table)

    # SSIS Execute SQL Tasks.
    results = run_all(
        connection,
        settings,
        procedure_params,
    )

    # SSIS: Get Done Folder -> Move To Done
    done_folder = get_done_folder(settings, subfolder)
    moved_to = move_file(file_path, done_folder)

    detail_lines = [
        f"Subfolder: {subfolder.name}",
        f"Rows loaded: {inserted}",
        f"Moved to: {moved_to}",
    ]

    for proc_name, rows in results.items():
        if rows:
            detail_lines.append(f"{proc_name} returned: {rows[:10]}")

    send_success_mail(
        settings,
        file_path.name,
        "\n".join(detail_lines),
    )

    LOGGER.info(
        "SUCCESS: %s -> %s",
        file_path.name,
        moved_to,
    )


def run():
    settings = load_settings()
    LOGGER.info("========== APC AUTOMATION START ==========")
    LOGGER.info("Process root: %s", settings.process_root)

    with RunLock(LOCK_PATH):
        connection = None
        temp_table_created = False
        processed_count = 0
        failed_count = 0

        try:
            connection = get_connection(settings)
            LOGGER.info("Connected to SQL Server.")

            # SSIS: Drop and Create table.
            create_temp_table(connection, settings.temp_table)
            temp_table_created = True
            LOGGER.info("Created temp table: %s", settings.temp_table)

            subfolders = get_subfolders(
                settings.process_root,
                settings.recursive_subfolders,
            )

            if not subfolders:
                LOGGER.info("No subfolders found under process root.")

            procedure_params = load_parameter_config(
                PROJECT_ROOT / "config" / "procedure_params.json"
            )

            for subfolder in subfolders:
                LOGGER.info("Processing subfolder: %s", subfolder)

                files = get_excel_files(
                    subfolder,
                    settings.allowed_extensions,
                )

                LOGGER.info(
                    "Found %d Excel file(s) in %s",
                    len(files),
                    subfolder,
                )

                for file_path in files:
                    if (
                        settings.max_files_per_run > 0
                        and processed_count >= settings.max_files_per_run
                    ):
                        LOGGER.info("MAX_FILES_PER_RUN reached.")
                        break

                    try:
                        process_file(
                            connection,
                            settings,
                            file_path,
                            subfolder,
                            procedure_params,
                        )
                        processed_count += 1

                    except Exception as exc:
                        failed_count += 1
                        LOGGER.exception(
                            "FAILED: %s",
                            file_path,
                        )

                        # SSIS failure path:
                        # Get Error Folder -> Move To Error -> Failure Mail
                        try:
                            error_folder = get_error_folder(
                                settings,
                                subfolder,
                            )
                            moved_to = move_file(
                                file_path,
                                error_folder,
                            )
                            LOGGER.info(
                                "Moved failed file to: %s",
                                moved_to,
                            )
                        except Exception:
                            LOGGER.exception(
                                "Could not move failed file to error folder."
                            )

                        try:
                            send_failure_mail(
                                settings,
                                file_path.name,
                                f"{type(exc).__name__}: {exc}\n\n"
                                f"{traceback.format_exc()}",
                            )
                        except Exception:
                            LOGGER.exception(
                                "Could not send failure email."
                            )

                if (
                    settings.max_files_per_run > 0
                    and processed_count >= settings.max_files_per_run
                ):
                    break

        finally:
            if connection is not None:
                try:
                    if temp_table_created and settings.delete_temp_table_on_exit:
                        drop_temp_table(connection, settings.temp_table)
                        LOGGER.info(
                            "Dropped temp table: %s",
                            settings.temp_table,
                        )
                except Exception:
                    LOGGER.exception("Could not drop temp table.")

                connection.close()
                LOGGER.info("SQL connection closed.")

        LOGGER.info(
            "========== APC AUTOMATION END | processed=%d failed=%d ==========",
            processed_count,
            failed_count,
        )

        # A non-zero exit code is useful to Windows Task Scheduler/monitoring.
        if failed_count:
            return 2

        return 0


if __name__ == "__main__":
    try:
        raise SystemExit(run())
    except Exception:
        LOGGER.exception("Fatal APC automation error.")
        raise SystemExit(1)
