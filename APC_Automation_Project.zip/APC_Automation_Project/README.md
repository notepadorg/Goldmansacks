# APC Manual Process - Python Automation

This project is a Python replacement framework for the SSIS package shown in the provided screenshots.

## SSIS flow represented

1. Get mail/configuration
2. Get subfolders under the APC process root
3. Create `dbo.tmpAPCManualupdate`
4. For each subfolder:
   - Find Excel files
   - Validate filename convention
   - Excel Source
   - Data Conversion
   - Load `dbo.tmpAPCManualupdate`
   - `EXEC papcManualUpdate`
   - `EXEC papcLoadRelatedClaims`
   - `EXEC papcUpdateCount`
   - `EXEC papcNullZipCount`
   - Get Done Folder
   - Move file to Done
   - Send success mail
5. If a file fails:
   - Get Error Folder
   - Move file to Error
   - Send failure mail
6. Drop the temporary table at the end

## Excel mapping captured from the supplied workbook screenshot

| Excel column | SQL temporary-table column |
|---|---|
| Claimnumber | Claimnumber |
| Taxid | TaxId |
| Campus Unit | Campus_unit |
| NPI | NPIID |
| ProviderName | ProviderName |
| Address_line1 | Address_line1 |
| Address_line2 | Address_line2 |
| City | City |
| State | State |
| Zip_code | Zip_code |
| UpdatedBY | UpdatedBY |
| AuditProgram | AuditProgram |

## Important

The project intentionally contains placeholders instead of company-specific:
- server names
- network paths
- email addresses
- credentials
- claim data

Do not commit `.env`.

The stored-procedure parameter requirements were not visible in the supplied screenshots. By default, the project calls the four procedures with no parameters. If the real SSIS Execute SQL Tasks pass parameters, configure `config/procedure_params.json` and set `PROCEDURES_HAVE_PARAMETERS=true`.

The exact SSIS logic used to construct per-subfolder Done/Error paths may also be more specific than the screenshots reveal. The Python implementation currently uses:

`DONE_ROOT / <subfolder name>`

and

`ERROR_ROOT / <subfolder name>`

If your SSIS Script Task/expressions construct another path, modify only `get_done_folder()` and `get_error_folder()` in `main.py`.

## Setup on Windows

### 1. Install Python

Use the Python version approved by your company.

Check:

```powershell
python --version
```

### 2. Create a virtual environment

From this project folder:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

### 3. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Install SQL Server ODBC driver

The machine must have a Microsoft SQL Server ODBC driver that matches `DB_DRIVER` in `.env`.

Check available drivers:

```powershell
python -c "import pyodbc; print(pyodbc.drivers())"
```

If the company machine already has the driver used by the SSIS connection manager, use that driver name in `.env`.

### 5. Configure `.env`

Copy:

```text
.env.example
```

to:

```text
.env
```

Fill in the company-approved values locally.

### 6. Test the database connection

```powershell
python -c "from database import get_connection; c=get_connection(); print('DB connection OK'); c.close()"
```

### 7. Test the application

Start with a controlled test folder and a test Excel file.

```powershell
python main.py
```

Check:

```text
logs\apc_automation.log
```

## Stored procedure parameters

If the SSIS Execute SQL Task has no parameters:

```env
PROCEDURES_HAVE_PARAMETERS=false
```

If parameters are required, edit:

```text
config/procedure_params.json
```

Example structure:

```json
{
  "papcManualUpdate": ["VALUE1", "VALUE2"],
  "papcLoadRelatedClaims": [],
  "papcUpdateCount": [],
  "papcNullZipCount": []
}
```

Do not copy the example values blindly. Use the parameter order and values required by the actual SSIS Execute SQL Task.

## Testing strategy

Do NOT point the first test directly at production folders.

Recommended sequence:

1. Test with a copied sample Excel file.
2. Use a test database/table.
3. Verify the 12-column Excel mapping.
4. Verify the temp-table row count.
5. Verify each stored procedure.
6. Verify successful file movement.
7. Test a deliberately invalid Excel file.
8. Verify movement to Error.
9. Verify failure email.
10. Only then use the production configuration after company approval.

## Windows Task Scheduler

After manual testing is approved:

1. Open **Task Scheduler**.
2. Create a task.
3. Choose the approved service/account.
4. Set the required trigger.
5. Action: **Start a program**.
6. Program:

```text
C:\Path\To\APC_Automation\.venv\Scripts\python.exe
```

7. Arguments:

```text
C:\Path\To\APC_Automation\main.py
```

8. Start in:

```text
C:\Path\To\APC_Automation
```

The account running the task must have:
- access to the network share
- SQL Server permissions
- permission to move files
- SMTP permission if email is enabled

For network shares, prefer the same Windows/service account that already has the permissions used by the SSIS job.

## Return codes

- `0` = run completed without file failures
- `1` = fatal application/setup error
- `2` = run completed but one or more files failed

This makes the task easier to monitor.

## Security

Never put:
- passwords
- access tokens
- production credentials
- real claim data

into source code or Git.

Use the company's approved secret-management/configuration process for production.
