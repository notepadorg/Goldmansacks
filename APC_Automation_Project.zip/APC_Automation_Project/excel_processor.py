from __future__ import annotations

from pathlib import Path

import pandas as pd


SOURCE_COLUMNS = [
    "Claimnumber",
    "Taxid",
    "Campus Unit",
    "NPI",
    "ProviderName",
    "Address_line1",
    "Address_line2",
    "City",
    "State",
    "Zip_code",
    "UpdatedBY",
    "AuditProgram",
]

COLUMN_MAPPING = {
    "Claimnumber": "Claimnumber",
    "Taxid": "TaxId",
    "Campus Unit": "Campus_unit",
    "NPI": "NPIID",
    "ProviderName": "ProviderName",
    "Address_line1": "Address_line1",
    "Address_line2": "Address_line2",
    "City": "City",
    "State": "State",
    "Zip_code": "Zip_code",
    "UpdatedBY": "UpdatedBY",
    "AuditProgram": "AuditProgram",
}

TARGET_COLUMNS = list(COLUMN_MAPPING.values())


def read_excel(file_path: Path) -> pd.DataFrame:
    # dtype=str is deliberate: it helps preserve identifiers such as ZIP codes.
    df = pd.read_excel(
        file_path,
        dtype=str,
        engine="openpyxl",
    )

    df.columns = [str(c).strip() for c in df.columns]

    missing = [c for c in SOURCE_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            f"{file_path.name}: missing required Excel columns: {missing}"
        )

    # Match the SSIS mapping exactly and ignore unrelated Excel columns.
    df = df[SOURCE_COLUMNS].rename(columns=COLUMN_MAPPING)

    return convert_data(df)


def convert_data(df: pd.DataFrame) -> pd.DataFrame:
    """Equivalent of the SSIS Data Conversion stage for this mapping."""
    df = df.copy()

    for column in TARGET_COLUMNS:
        df[column] = df[column].where(df[column].notna(), None)

        # Normalize Excel numeric-looking values such as 12345.0.
        df[column] = df[column].map(
            lambda value: (
                None
                if value is None
                else (
                    str(int(float(value)))
                    if isinstance(value, float) and value.is_integer()
                    else str(value).strip()
                )
            )
        )

        # Empty strings become SQL NULL, which is usually closer to SSIS behavior.
        df[column] = df[column].replace({"": None})

    return df


def dataframe_rows(df: pd.DataFrame):
    for row in df[TARGET_COLUMNS].itertuples(index=False, name=None):
        yield row
